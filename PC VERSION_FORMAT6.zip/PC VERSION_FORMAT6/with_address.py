import re,time
from termcolor import colored
from sys import prefix
import requests,random,json,os
cwd = os.getcwd()
from bs4 import BeautifulSoup
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)
from selenium.webdriver.chrome.service import Service
from multiprocessing import Pool
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait as wait
from selenium.webdriver.support import expected_conditions as EC
from faker import Faker
fake = Faker('en_US')
 
 
 
mobile_emulation = {
    "deviceMetrics": { "width": 360, "height": 650, "pixelRatio": 3.4 },
    }
brave_path = r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe"
driver_path= f"{cwd}\\chromedriver.exe"
firefox_options = webdriver.ChromeOptions()
firefox_options.add_argument('--no-sandbox')

firefox_options.headless = False
firefox_options.add_argument('--disable-setuid-sandbox')
firefox_options.add_argument('disable-infobars')
firefox_options.add_argument('--ignore-certifcate-errors')
firefox_options.add_argument('--ignore-certifcate-errors-spki-list')
firefox_options.add_argument("--incognito")
firefox_options.add_argument('--no-first-run')
firefox_options.add_argument('--disable-dev-shm-usage')
firefox_options.add_argument("--disable-infobars")
firefox_options.add_argument("--disable-extensions")
firefox_options.add_argument("--disable-popup-blocking")
firefox_options.add_argument('--log-level=3')
#CUSTOM ATUOR SIZE 
#firefox_options.add_argument("--window-size=500,800")
firefox_options.add_argument("--start-maximized")
firefox_options.add_argument('--disable-blink-features=AutomationControlled')
firefox_options.add_experimental_option("useAutomationExtension", False)
firefox_options.add_experimental_option("excludeSwitches",["enable-automation"])
firefox_options.add_experimental_option('excludeSwitches', ['enable-logging'])
firefox_options.add_argument('--disable-notifications')
from selenium.webdriver.common.action_chains import ActionChains
firefox_options.binary_location = brave_path
random_angka = random.randint(100,999)
random_angka_dua = random.randint(10,99)
header = {"accept-encoding": "gzip, deflate",
         "content-type": "application/json; charset=utf-8",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "content-length": "76",
    "content-type": "application/json",
    "cookie": 'top-navigation-experiment-variant=0; forcedRegABExpId=HMAxRyAXROWAsfH9HxDqVQ; forcedRegABVariant=0; _gcl_au=1.1.1528467627.1640452192; _ga=GA1.2.1177011315.1640452192; _gid=GA1.2.971393706.1640452192; _fbp=fb.1.1640452193216.1940445925; paa-did=a.c.kxm2vnuy.66b8711a-9ea5-4d57-bb11-ce8591ea22b9; _pin_unauth=dWlkPU9EYzRabVl3TVRndE5UVmlNeTAwWkRJNUxXRTNNREl0TlRZd1l6ZGhNR1UyTW1ZMw; AF_SYNC=1640452195103; afUserId=4322f47b-944a-4949-bc48-fad52478a2b5-p; g_state={"i_p":1640459400899,"i_l":1}; OptanonAlertBoxClosed=2021-12-25T17:10:04.487Z; sid=s%3AEw0vmvGzZbOZkonmA9msuUBGDxkHm71q.zeaoZPlrm06pe4kLdxKcsJK8I6fiRQKL9oaa5BxNt9A; isOpened=true; IR_gbd=picsart.com; _fbc=fb.1.1640518552375.IwAR3fyXlJ1PSgh3jKvyUw3jP6dPZ7VRqK6v-By_hbnaO38ycJKzb8RixQifs; ab.storage.deviceId.4fc46d16-14ad-4944-ba4b-c874f391cb00=%7B%22g%22%3A%22cefd7c95-4389-8ecf-e619-58d6aff13614%22%2C%22c%22%3A1640452254332%2C%22l%22%3A1640518552478%7D; ab.storage.userId.4fc46d16-14ad-4944-ba4b-c874f391cb00=%7B%22g%22%3A%22378148284058101%22%2C%22c%22%3A1640452287372%2C%22l%22%3A1640518552479%7D; IR_PI=30f60a67-65a6-11ec-8fd8-2b13cb31605b%7C1640604967147; __zlcmid=17jkaDwghOocvF9; currentLanguage=en; tatari-cookie-test=11201914; tatari-user-cookie=378148284058101; IR_11703=1640518746737%7C0%7C1640518746737%7C%7C; OptanonConsent=isGpcEnabled=0&datestamp=Sun+Dec+26+2021+18%3A39%3A07+GMT%2B0700+(Waktu+Indonesia+Barat)&version=6.20.0&isIABGlobal=false&hosts=&consentId=cb7197ac-5209-4679-b70b-8a58e47205f8&interactionCount=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0002%3A1%2CC0003%3A1%2CC0004%3A1&geolocation=%3B&AwaitingReconsent=false; tatari-session-cookie=538817ee-e7fc-f812-8174-85987aa7c54a; ab.storage.sessionId.4fc46d16-14ad-4944-ba4b-c874f391cb00=%7B%22g%22%3A%22b64d4c64-d3c8-ba89-963d-49e761f9a048%22%2C%22e%22%3A1640520601808%2C%22c%22%3A1640518552475%2C%22l%22%3A1640518801808%7D',
    "deviceid": 'a.c.kxm2vnuy.66b8711a-9ea5-4d57-bb11-ce8591ea22b9',
    "origin": "https://picsart.com",
    "referer": "https://picsart.com/universe-trial?fbclid=IwAR3fyXlJ1PSgh3jKvyUw3jP6dPZ7VRqK6v-By_hbnaO38ycJKzb8RixQifs",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "user-agent": 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1'
    }
states = {
    'AK': 'Alaska',
    'AL': 'Alabama',
    'AR': 'Arkansas',
    'AZ': 'Arizona',
    'CA': 'California',
    'CO': 'Colorado',
    'CT': 'Connecticut',
    'DC': 'District of Columbia',
    'DE': 'Delaware',
    'FL': 'Florida',
    'GA': 'Georgia',
    'HI': 'Hawaii',
    'IA': 'Iowa',
    'ID': 'Idaho',
    'IL': 'Illinois',
    'IN': 'Indiana',
    'KS': 'Kansas',
    'KY': 'Kentucky',
    'LA': 'Louisiana',
    'MA': 'Massachusetts',
    'MD': 'Maryland',
    'ME': 'Maine',
    'MI': 'Michigan',
    'MN': 'Minnesota',
    'MO': 'Missouri',
    'MS': 'Mississippi',
    'MT': 'Montana',
    'NC': 'North Carolina',
    'ND': 'North Dakota',
    'NE': 'Nebraska',
    'NH': 'New Hampshire',
    'NJ': 'New Jersey',
    'NM': 'New Mexico',
    'NV': 'Nevada',
    'NY': 'New York',
    'OH': 'Ohio',
    'OK': 'Oklahoma',
    'OR': 'Oregon',
    'PA': 'Pennsylvania',
    'RI': 'Rhode Island',
    'SC': 'South Carolina',
    'SD': 'South Dakota',
    'TN': 'Tennessee',
    'TX': 'Texas',
    'UT': 'Utah',
    'VA': 'Virginia',
    'VT': 'Vermont',
    'WA': 'Washington',
    'WI': 'Wisconsin',
    'WV': 'West Virginia',
    'WY': 'Wyoming'
}
def xpath_el(el):
    element_all = wait(browser,15).until(EC.presence_of_element_located((By.XPATH, el)))
    browser.execute_script("arguments[0].scrollIntoView();", element_all)
    return browser.execute_script("arguments[0].click();", element_all)

def xpath_ex(el):
    element_all = wait(browser,0.3).until(EC.presence_of_element_located((By.XPATH, el)))
    browser.execute_script("arguments[0].scrollIntoView();", element_all)
    return browser.execute_script("arguments[0].click();", element_all)

name = ["Bellamy","Clara","Monica","Michael","Michelle","Jeniffer","Robby","Eva","Jackson","Alex","Franky","Jefford","Olivia","Daisy","Caroline","Leo"]
def sign_up(email, password,new_cc):
    global browser
    
    name_card = random.choice(name)
 
    
    get_cc = new_cc.replace("Live | ","").replace(" [BIN: - - - ][GATE:01] @/ChkNET-ID","")
    get_data = get_cc.split("|")
    number_card = get_data[0]
    month = get_data[1]
    year = get_data[2]
    get_year = str(year).split("20")
    expired_card = str(month)+f"{get_year[1]}"
    security_card = get_data[3]

    #firefox_options.add_experimental_option("mobileEmulation", mobile_emulation)
    firefox_options.add_argument(f"user-agent=Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1")
    browser = webdriver.Chrome(options=firefox_options,executable_path=driver_path)
    
 
    #Create a var of the window
   
    #Set the focus back to content to re-engage with page elements
   
    browser.get('https://picsart.com/universe-trial')
    browser.execute_script("document.body.style.zoom='80%'") 
    win = browser.find_element_by_tag_name("body")
    #Send the key combination to the window itself rather than the web content to zoom out
    #(change the "-" to "+" if you want to zoom in)
    win.send_keys(Keys.CONTROL + "-")
    win.send_keys(Keys.CONTROL + "-")
    print("[+] Trying to Creating New Account...!")
    with open('log.txt','a',encoding='utf-8') as f: f.write(f'Trying to Creating New Account...! \n')
     
    element_all = wait(browser,13).until(EC.presence_of_element_located((By.XPATH,'(//span[contains(@class,"button-text")])[1]')))
    
    browser.execute_script("arguments[0].click();", element_all)
    try:
        xpath_el('//button[@id="onetrust-accept-btn-handler"]')
        #xpath_el('//a[contains(@class,"switchAction")]')
    except:
        pass
 
    email_input = wait(browser,40).until(EC.presence_of_element_located((By.XPATH, f'//input[@name="email"]')))
    email_input.send_keys(email)
    sleep(0.5)
    el = wait(browser,40).until(EC.presence_of_element_located((By.XPATH, f'//i[@aria-label="Show password"]')))
    browser.execute_script("arguments[0].click();", el)
    pw_input = wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//input[@name="password"]')))
    pw_input.send_keys(password)
    element_all = wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//button[@type="submit"]'))) 
    browser.execute_script("arguments[0].click();", element_all)
    n = 1
    while True:
        if n == 3:
            break
        try:
            wait(browser,0.5).until(EC.presence_of_element_located((By.XPATH, f'//input[@aria-label="Pay using credit card"]'))).click()

            break
        except:
            try:
                wait(browser,0.5).until(EC.presence_of_element_located((By.XPATH, f'//button[@type="submit"]'))).click()
            except:
                try:
                    wait(browser,0.5).until(EC.presence_of_element_located((By.XPATH, f"//span[contains(text(),'Something went wrong!')]")))
                    print("[+] Run Again! Change IP!")
                    break
                except:
                    n = n+1
                    pass
    while True:
            
        if n == 5:
            print("[+] Verification Failed!")
            with open('log.txt','a',encoding='utf-8') as f: f.write(f'Verification Failed!\n')
            break
        URL = f'https://getnada.com/api/v1/inboxes/{email}'
        r = requests.get(URL).json()
        #getting the latest message
        
        try:
            global uid
            uid = r['msgs'][0]['uid']
        
            mes = requests.get(f'https://getnada.com/api/v1/messages/html/{uid}')
            mes1 = BeautifulSoup(mes.content,'html.parser')
            sleep(1)
            get_data = mes1.prettify()
            get_data = get_data.split('href="https://picsart.com/activate/')
            get_data = get_data[1].split('style="display: block; padding-left: 45px;')
            get_data = get_data[0]
            get_data = get_data.split('"')
            url_activation = f'https://picsart.com/activate/{get_data[0]}'
            print(f'[+] Creating New Account Success!')
            with open('log.txt','a',encoding='utf-8') as f: f.write(f'Creating New Account Success! \n')
            requests.get(f'https://picsart.com/activate/{get_data[0]}')
            print("[+] Verification Email Success!")
            with open('log.txt','a',encoding='utf-8') as f: f.write(f'Verification Email Success!\n')
            print("[+] Trying to Execution the Account with this Credit Card and this Billing Address details...!")
            with open('log.txt','a',encoding='utf-8') as f: f.write(f'Trying to Execution the Account with this Credit Card and this Billing Address details...! \n')
          
            break
        except IndexError:
            print("[+] Your Email doesn't have a new message, Reload!")
            with open('log.txt','a',encoding='utf-8') as f: f.write("Your Email doesn't have a new message, Reload! \n")
            n = n+1
            sleep(2)
    street = fake.address()
    street = street.split("\n")
    street = street[0]
    city = fake.city()
    

    get_add = requests.get('https://www.bestrandoms.com/random-address-in-us?quantity=20',json = {'abbr': 'us',
    'quantity': 1})
    get_data_prov = get_add.text.split('State/province/area: </b>&nbsp;&nbsp;''')
    
    get_data_prov = get_data_prov[1]
    get_data_prov = get_data_prov.split(r"</span></p><p><span><b>Phone number</b>")


    state = get_data_prov[0]

    get_zip = get_add.text.split(r"<b>Zip code</b>&nbsp;&nbsp;")
    get_zip = get_zip[1]
    get_zip = get_zip.split(r"</span></p><p><span><b>Country")

    zip = get_zip[0]
    print(f"[+] {number_card}|{month}|{year}|{security_card}|{name_card}|")
    with open('log.txt','a',encoding='utf-8') as f: f.write(f'{number_card}|{month}|{year}|{security_card}|{name_card}|')
    print(f"[+] United State|{street}|{city}|{state}|{zip}|")
    with open('log.txt','a',encoding='utf-8') as f: f.write(f"United State|{street}|{city}|{state}|{zip}|")
    wait(browser, 40).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH,"(//iframe[contains(@src,'https://checkoutshopper-live.adyen.com/')])[1]")))
    input_number_card = wait(browser,30).until(EC.presence_of_element_located((By.XPATH, f'//input[@id="encryptedCardNumber"]')))
    input_number_card.send_keys(number_card)
    sleep(0.5)
    browser.switch_to.default_content()
    #wait(browser, 10).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH,"(//iframe[contains(@src,'https://checkoutshopper-live.adyen.com/')])")))
    wait(browser, 10).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH,"(//iframe[contains(@src,'https://checkoutshopper-live.adyen.com/')])[2]")))
    input_expired_card = wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//input[@id="encryptedExpiryDate"]')))
    input_expired_card.send_keys(expired_card)
    sleep(0.5)
    browser.switch_to.default_content()
    #  wait(browser, 10).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH,"(//iframe[contains(@src,'https://checkoutshopper-live.adyen.com/')])")))
    wait(browser, 10).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH,"(//iframe[contains(@src,'https://checkoutshopper-live.adyen.com/')])[3]")))
    input_security_card = wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//input[@id="encryptedSecurityCode"]')))
    input_security_card.send_keys(security_card)
    sleep(2)
    browser.switch_to.default_content()

    input_name_card = wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//input[@placeholder="Name on Card"]')))
    input_name_card.send_keys(name_card)
    sleep(0.5)
    #xpath_el('/html/body/div[3]/div/div/div/div/ul/li[3]/div/div[1]/form/div[1]/div[1]/div[1]/div/div/div[2]/div[4]/form/div[2]') 
    try:
        wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//option[@value="United States"]'))).click()
 
    except:
        xpath_el('/html/body/div[3]/div/div/div/div/ul/li[3]/div/div[1]/form/div[1]/div[1]/div[1]/div/div/div[2]/div[4]/form/div[2]/select/option[197]') 
 
    street_input = wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//input[@data-test="street"]')))
    street_input.send_keys(street)
    city_input = wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//input[@data-test="city"]')))
    city_input.send_keys(city)
    state_input = wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//input[@data-test="state"]')))
    state_input.send_keys(state)
    zip_input = wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//input[@data-test="zip"]')))
    zip_input.send_keys(zip)
    sleep(8)
    n = 1
    try:
        wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//button[@id="onetrust-accept-btn-handler"]'))).click()
    except:
        pass
    try:
        xpath_ex('//button[@data-test="checkout-form-payment-button-adyen"]')
        
        el = wait(browser,0.3).until(EC.presence_of_element_located((By.XPATH, f'//button[@data-test="checkout-form-payment-button-adyen"]')))
        el.click()
        action = ActionChains(browser)
        for i in range(0,3):               
            try:
                action.double_click(on_element = el)
            except:
                pass
    except:
        pass
    
    while True:
        sleep(5)
        try:
            check_notif = wait(browser,10).until(EC.presence_of_element_located((By.XPATH, f'//*[text()="Error verifying reCAPTCHA" or text()="Your payment failed, please try again."]'))).text
            
            if "Your" in check_notif:
                check_notif = "Your Payment was Failed!"
                print(f"[+] {check_notif}")
                with open('log.txt','a',encoding='utf-8') as f: f.write(f'{check_notif} \n')
                print(f"[+] Now Trying to Delete The Account...!")
                with open('log.txt','a',encoding='utf-8') as f: f.write(f'Now Trying to Delete The Account...! \n')
                browser.get("https://picsart.com/settings") 
                element_all = wait(browser,35).until(EC.presence_of_element_located((By.XPATH, '//span[@class="settings-account-delete-button-container-trigger"]')))
                browser.execute_script("arguments[0].scrollIntoView();", element_all)
                browser.execute_script("arguments[0].click();", element_all)
                sleep(2)
                xpath_el('''//*[text()="I don't see any relevant content"]''')
                sleep(2)
                 
                element_all = wait(browser,35).until(EC.presence_of_element_located((By.XPATH, '//input[@type="password"]')))
                element_all.send_keys(password)
                xpath_el('(//button[@class="default-button big-button primary-button"])[2]')
                xpath_el('//button[@class="default-button big-button primary-button settings-account-delete-modal-footer-button-black"]')
                print('[+] Success Deleted the Account!')
                with open('log.txt','a',encoding='utf-8') as f: f.write(f'Success Deleted the Account! \n')
                print('[+] And these are few details of your PicsArt Account')
                with open('log.txt','a',encoding='utf-8') as f: f.write(f'And these are few details of your PicsArt Account\n')
                print(f'[+] Email: {email}')
                print(f'[+] You Can Try it Again Later! The data now was saved to resultfailed.txt')
                with open('log.txt','a',encoding='utf-8') as f: f.write(f'You Can Try it Again Later! The data now was saved to resultfailed.txt \n')
                with open('resultfailed.txt','a') as f:
                    f.write(f"{email}\n")
                status_loop = "False"
                    
                break
            else:
                print('[+] Error verifying reCAPTCHA, Change your IP Right Now!')
                
                with open('log.txt','a',encoding='utf-8') as f: f.write(f'Error verifying reCAPTCHA, Change your IP Right Now \n')
                print('[+] Waiting Changing Your IP...')
                sleep(10)
                with open('log.txt','a',encoding='utf-8') as f: f.write(f'Waiting Changing Your IP... \n')
                input('[+] Done Changing! Press ENTER to Running Script Again ')
                xpath_ex('//button[@data-test="checkout-form-payment-button-adyen"]')
                with open('log.txt','a',encoding='utf-8') as f: f.write(f'Done Changing! Press ENTER to Running Script Again \n')
        except:
            status_loop = "True"
            break
            
    if status_loop == "False":
        info_ip = requests.get('https://ipwhois.app/json/').json()
        end = time.time()
        elapsed = end - start
        elapsed = elapsed/60
        elapsed = str(elapsed)
        try:
            elapsed = elapsed.split(".")
            minutes = elapsed[0]
            seconds = elapsed[1]
            
        except:
            minutes = 0
            seconds = 0
        print(colored(f"[+] Elapsed Time: {minutes} minutes {seconds[1:3]} seconds",'green'))
        with open('log.txt','a',encoding='utf-8') as f: f.write(f'Elapsed Time: {minutes} minutes {seconds[1:3]} seconds \n')
        print(colored(f'[+] Your Previous IP is {info_ip["ip"]} [{info_ip["country"]} - {info_ip["region"]}] [{lim}x]','green'))
        with open('log.txt','a',encoding='utf-8') as f: f.write(f'Your Previous IP is {info_ip["ip"]} [{info_ip["country"]} - {info_ip["region"]}] [{lim}x]\n')
        
    else:   
        try:
            URL = f'https://getnada.com/api/v1/inboxes/{email}'
            r = requests.get(URL).json()
            uid = r['msgs'][0]['uid']

            mes = requests.get(f'https://getnada.com/api/v1/messages/html/{uid}')
            mes1 = BeautifulSoup(mes.content,'html.parser')
            get_data = mes1.prettify()
            
            data = get_data.split('''<p style="margin:44px 0 16px 0;color:#080808;font-size:24px;line-height:32px;font-weight:600;font-family:'Open Sans',Arial,sans-serif;">''')
            data = data[1].split("Picsart Gold!")
            print("[+] Welcome To Gold!")
            status_notif = "True"
        except:
            status_notif = "False"
        
        
        browser.get("https://picsart.com/settings") 
        
        sleep(1)
        browser.refresh()
        sleep(1)
        # browser.refresh()
        sleep(2)
        username = wait(browser,55).until(EC.presence_of_element_located((By.XPATH, f'//input[@data-test="username-input"]'))).get_attribute('value')
        xpath_el('//li[@data-idx="billing-and-subscriptions"]')
        
        date_buy = wait(browser,15).until(EC.presence_of_element_located((By.XPATH, f'(//div[@class="settings-invoices-list-item-cell list-item-date"])[1]'))).text
        while True:
            try:
                date_end = wait(browser,5).until(EC.presence_of_element_located((By.XPATH, f'//p[@class="subscriptions-plan-details-description"]'))).text
                break
            except:
                try:
                    browser.get("https://picsart.com/settings") 
                    xpath_el('//li[@data-idx="billing-and-subscriptions"]')
                    date_end = wait(browser,5).until(EC.presence_of_element_located((By.XPATH, f'//p[@class="subscriptions-plan-details-description"]'))).text
                    break
                except:
                    pass
        sleep(1)
        browser.refresh()
        date_end = date_end.split("on ")
    
        if status_notif == "False":
            print("[+] Welcome To Gold!")
            
            with open('log.txt','a',encoding='utf-8') as f: f.write(f'Welcome To Gold! \n')
    
        print(f"[+] And these are few details of your PicsArt Account")
        with open('log.txt','a',encoding='utf-8') as f: f.write(f'And these are few details of your PicsArt Account \n')
        date_end = date_end[1].split(".")
        date_end = date_end[0]
        date_end = date_end.replace('.','')
        data_month_buy = date_buy.split(",")
        data_month_buy = data_month_buy[0].split(" ")
        data_month_buy = data_month_buy[0]
        data_month_end = date_end.split(",")
        data_month_end = data_month_end[0].split(" ")
        data_month_end = data_month_end[0]
        list_month = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
        get_idx_month_buy = list_month.index(data_month_buy)+1
        get_month_int_buy = "0"+str(get_idx_month_buy)
        get_idx_month_end= list_month.index(data_month_end)+1
        get_month_int_end = "0"+str(get_idx_month_end)
        date_buy_tgl = re.findall(r'\d+',date_buy)
        date_end_tgl = re.findall(r'\d+',date_end)
        if len(str(date_buy_tgl[0])) == 1:
            date_buy_tgl[0] = f"0{date_buy_tgl[0]}"
        if len(str(date_end_tgl[0])) == 1:
            date_end_tgl[0] = f"0{date_end_tgl[0]}"   
                
        print(f"[+] Username: {username} | Start: {date_buy_tgl[0]}/{get_month_int_buy}/2022 ({date_buy}) | Exp: {date_end_tgl[0]}/{get_month_int_end}/2022 ({date_end}) |")
        with open('log.txt','a',encoding='utf-8') as f: f.write(f'Username: {username} | Start: {date_buy_tgl[0]}/{get_month_int_buy}-2022 ({date_buy}) | Exp: {date_end_tgl[0]}-{get_month_int_end}-2022 ({date_end}) | \n')
            
        with open('resultsuccess.txt','a') as f:
            f.write(f"{email}|{password}|{date_buy_tgl[0]}/{get_month_int_buy}/2022 ({date_buy})|{date_end_tgl[0]}/{get_month_int_end}/2022 ({date_end})|{number_card}|{month}|{year}|{security_card}|{name_card}|Welcome To Gold!|\n")
        
    
        dats.remove(new_cc)
        with open('cc.txt','w',encoding='utf-8') as f: f.write(f'')
        for m in dats[:]:
            with open('cc.txt','a',encoding='utf-8') as f: f.write(f'{m}\n')

        print(f"[+] Great Job! The data now was saved to resultsuccess.txt")
        info_ip = requests.get('https://ipwhois.app/json/').json()
        end = time.time()
        elapsed = end - start
        elapsed = elapsed/60
        elapsed = str(elapsed)
        try:
            elapsed = elapsed.split(".")
            minutes = elapsed[0]
            
            seconds = elapsed[1]
        except:
            minutes = 0
            seconds = 0
        print(colored(f"[+] Elapsed Time: {minutes} minutes {seconds[1:3]} seconds",'green'))
        with open('log.txt','a',encoding='utf-8') as f: f.write(f'Elapsed Time: {minutes} minutes {seconds[1:3]} seconds\n')
        print(colored(f'[+] Your Previous IP is {info_ip["ip"]} [{info_ip["country"]} - {info_ip["region"]}] [{lim}x]','green'))
        with open('log.txt','a',encoding='utf-8') as f: f.write(f'Your Previous IP is {info_ip["ip"]} [{info_ip["country"]} - {info_ip["region"]}] [{lim}x]\n')


def main():
    global dats
    print("[+] Auto Verification & Auto Payment PicsArt Gold Premium 3 Months (With Address Version)")
    with open('log.txt','a',encoding='utf-8') as f: f.write(f'[+] Auto Verification & Auto Payment PicsArt Gold Premium 3 Months (Without Address Version)\n')
    print("[+] URL: https://picsart.com/universe-trial")
    with open('log.txt','a',encoding='utf-8') as f: f.write(f'URL : https://picsart.com/universe-trial \n')
    print("[+] BIN: 543896xxxxxxx85x")
    with open('log.txt','a',encoding='utf-8') as f: f.write(f'BIN: 543896xxxxxxx85x \n')
    password = "panda123"
    file_list_akun = "cc.txt"
    myfile_akun = open(f"{cwd}\\{file_list_akun}","r")
    akun = myfile_akun.read()
    dats = akun.split("\n")
    global number
    number = 1
    global lim
    
    
    lim = 1
    format_email = ['getnada.com','abyssmail.com','boximail.com','clrmail.com','dropjar.com','getairmail.com','givmail.com','inboxbear.com','robot-mail.com','tafmail.com','vomoto.com','zetmail.com']
    
    for i in dats: 
        while True:
            try:
                email = input("[+] Please Submit Your Email: ")
                with open('log.txt','a',encoding='utf-8') as f: f.write(f'Please Submit Your Email: {email}\n')
                print("[+] Your Default Password is: panda123")
                with open('log.txt','a',encoding='utf-8') as f: f.write(f'Your Default Password is: panda123\n')
                
                prefix_mail = email.split('@')
                prefix_mail = prefix_mail[1]
                if any(prefix_mail in s for s in format_email):
                    
                    break
                else:
                    print(colored("[+] Wrong Email Format! Please Check Again...",'green'))
                    with open('log.txt','a',encoding='utf-8') as f: f.write("Wrong Email Format! Please Check Again...")
            except KeyboardInterrupt:
        
                print("\n[+] Exit!")
                exit()
            except:
                print(colored("[+] Wrong Email Format! Please Check Again...",'green'))
                with open('log.txt','a',encoding='utf-8') as f: f.write("Wrong Email Format! Please Check Again...")
            
                
            
        info_ip = requests.get('https://ipwhois.app/json/').json()
        global start
        start = time.time()
        print(colored("[+] Your Email Format is Correct", 'green'))
        with open('log.txt','a',encoding='utf-8') as f: f.write("Your Email Format is Correct")
        print(colored(f'[+] Your IP now is {info_ip["ip"]} [{info_ip["country"]} - {info_ip["city"]}] [{lim}x]', 'green'))
        with open('log.txt','a',encoding='utf-8') as f: f.write(f'Your IP now is {info_ip["ip"]} [{info_ip["country"]} - {info_ip["city"]}] [{lim}x]')
        sign_up(email, password, i)
        #os\.system\("notepad\.exe cc\.txt"\)
        number = number + 1
        lim = lim + 1
        if lim == 3:
            lim == 1

main() 